/*
Developed by Zachary Selk at the University of Alberta (zrselk@gmail.com)

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject
to the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR
ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

(MIT license, http://www.opensource.org/licenses/mit-license.html)
*/

package rars.tools;

//import jdk.incubator.foreign.MemoryAccess;
import rars.Globals;
import rars.riscv.hardware.*;
import rars.riscv.instructions.SW;
import rars.riscv.instructions.Store;
import rars.util.Binary;

import java.awt.*;
import java.util.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;

//Rars tool for playing and recording music


public class VirtualPiano extends AbstractToolAndApplication {

    private static final String heading = "Virtual Piano";
    private static final String version = "Version 1.0";


    private int offset = 0;

    //Pitches

    private int pitchList[] = {
            0x0000003C, //C Pitch
            0x0000003D, //C#/Db Pitch
            0x0000003E, //D Pitch
            0x0000003F, //D#/Eb Pitch
            0x00000040, //E Pitch
            0x00000041, //F Pitch
            0x00000042, //F#/Gb Pitch
            0x00000043, //G Pitch
            0x00000044, //G#/Ab Pitch
            0x00000045, //A Pitch
            0x00000046, //A#/Bb Pitch
            0x00000047  //B Pitch
    };


    //needed for restoring all pitches if value of pitch runs out of bounds
    private static final int[] restoreValues = {0x0000003C, 0x0000003D,  0x0000003E, 0x0000003F, 0x00000040,
            0x00000041, 0x00000042, 0x00000043, 0x00000044, 0x00000045, 0x00000046, 0x00000047};

    private static final int MAXOCTAVE = 120;
    private static final int MINOCTAVE = 12;

    private static final int RIGHTSHIFT = 0;
    private static final int LEFTSHIFT = 1;

    private static final String[] instrumentNames = {"Piano", "Chromatic Percussion", "Organ", "Guitar",
            "Bass", "Strings", "Ensemble", "Brass", "Reed", "Pipe", "Synth Lead", "Synth Pad", "Synth Effect", "Ethnic", "Percussion"};

    private static final int[] instrumentValues = {
            0x00000000, //Piano
            0x00000008, //Chromatic Percussion
            0x00000010, //Organ
            0x0000000c, //Guitar
            0x00000020, //Bass
            0x00000028, //Strings
            0x00000030, //Ensemble
            0x00000038, //Brass
            0x00000040, //Reed
            0x00000048, //Pipe
            0x00000050, //Synth Lead
            0x00000058, //Synth Pad
            0x00000060, //Synth Effect
            0x00000068, //Ethnic
            0x00000070, //Percussion
            0x00000078, //Sound Effect
    };

    private boolean record = false;

    java.util.List<Integer> recorded = new ArrayList<Integer>();

    private int setSelectedInstrument() {
        int currentInstrument = RegisterFile.getValue("a2");
        for(int i = 0; i < instrumentValues.length; i++) {
            if(instrumentValues[i] == currentInstrument) {
                return i;
            }
        }
        return -1;
    }
    private void pitchEvent(int pitch) {
        RegisterFile.updateRegister("a0", pitch);
        try
        {
            if(RegisterFile.getValue("a2") != -1) {
                Thread.sleep(100);
                RegisterFile.updateRegister("a0", 0);
            }
            if(record)
            {
                recorded.add(pitch);
            }
        }
        catch(InterruptedException ex)
        {
            Thread.currentThread().interrupt();
        }
    }

    private void shiftOctave(int shiftDirection) {
        if(shiftDirection == LEFTSHIFT) {
            for(int i = 0; i < pitchList.length; i++)
                if(pitchList[i] < MINOCTAVE)
                    pitchList[i] = restoreValues[i];
                else
                    pitchList[i] = pitchList[i] - 0x000000C;

        }
        else if (shiftDirection == RIGHTSHIFT) {
            for (int i = 0; i < pitchList.length; i++)
                if(pitchList[i] >= MAXOCTAVE)
                    pitchList[i] = restoreValues[i];
                else
                    pitchList[i] = pitchList[i] + 0x000000C;
        }
    }

    private void resetDataSegment() {
        RegisterFile.updateRegister("a0", 0x00000000);
        offset = 0;
        for(int i = 0; i < 512; i += 4) {
            try {
                Globals.memory.setWord(Memory.dataBaseAddress + i, 0x00000000);
            } catch (AddressErrorException e) {
                e.printStackTrace();
            }
        }
    }
    private void playRecording() throws AddressErrorException {
        int i = 0;
        do {
            try {
                int tmpPitch = Globals.memory.getWord(Memory.dataBaseAddress + i);
                RegisterFile.updateRegister("a0", tmpPitch);
                Thread.sleep(RegisterFile.getValue("a1"));

                i += 4;

            } catch (AddressErrorException | InterruptedException a) {
                a.printStackTrace();
            }
        } while((Globals.memory.getWord(Memory.dataBaseAddress + i)) != 0);
        RegisterFile.updateRegister("a0", 0x00000000);
    }

    ///////////////////////////////////////////////
    //GUI

    private JComponent buildSelectionArea()
    {

        JPanel selectionArea = new JPanel();
        //record Button
        JButton recordButton = new JButton("record");
        JButton playButton = new JButton("play");
        JButton saveButton = new JButton("save");
        //Instrument Combobox
        JComboBox<String> instrumentSelection = new JComboBox<String>(instrumentNames);
        //Volume Slider
        JSlider volumeSlider = new JSlider(JSlider.HORIZONTAL, 0, 127, RegisterFile.getValue("a3"));
        JSlider durationSlider = new JSlider(JSlider.HORIZONTAL, 0, 3000, RegisterFile.getValue("a1"));

        volumeSlider.setToolTipText("Volume");
        durationSlider.setToolTipText("Duration");

        recordButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        recorded.clear();
                        resetDataSegment();
                        record = true;
                    }
                });

        playButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            playRecording();
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        saveButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String asmCode = ".data\nmelody:\n.word ";
                        for (int i = 0; i < recorded.size(); i++)
                            asmCode += recorded.get(i).toString() + " ";

                        asmCode += "\n\n.text\ninitialize:\n" +
                                "li a7, 33\n" +
                                "li a1, " + RegisterFile.getValue("a1") +
                                "\nli a2, " + RegisterFile.getValue("a2") +
                                "\nli a3, " + RegisterFile.getValue("a3") +
                                "\nla a4, melody\n" +
                                "li t0, 0 \n" +
                                "li t1, " + ((recorded.size() * 4) - 4) +
                                "\n" +
                                "\nmain:\n" +
                                "bge t1, t0, playMelody\n" +
                                "j exit #if t1 = t0 exit\n" +
                                "\nplayMelody:\n" +
                                "lw a0, 0(a4) #load word from array\n" +
                                "addi t0, t0, 4 #i++\n" +
                                "addi a4, a4, 4 #array go one position forward\n" +
                                "ecall \n" +
                                "j main\n" +
                                "\n" +
                                "exit:\n" +
                                "addi zero, zero, 0";

                        //Show Code and automatically copy to clipboard
                        JOptionPane.showMessageDialog(theWindow, asmCode);
                        StringSelection stringSelection = new StringSelection(asmCode);
                        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                        clipboard.setContents(stringSelection, null);
                    }
                });


        volumeSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSlider source = (JSlider)e.getSource();
                RegisterFile.updateRegister("a3", source.getValue());
            }
        });

        durationSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSlider source = (JSlider)e.getSource();
                RegisterFile.updateRegister("a1", source.getValue());
            }
        });

        instrumentSelection.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        RegisterFile.updateRegister("a2", instrumentSelection.getSelectedIndex());
                    }
                });

        if(setSelectedInstrument() != -1)
            instrumentSelection.setSelectedIndex(setSelectedInstrument());

        selectionArea.add(recordButton);
        selectionArea.add(playButton);
        selectionArea.add(saveButton);
        selectionArea.add(durationSlider);
        selectionArea.add(volumeSlider);
        selectionArea.add(instrumentSelection);

        return selectionArea;
    }

    private JComponent buildKeyArea()
    {

        JPanel keyArea = new JPanel();

        //add piano keys
        JButton cButton = new JButton("C");
        JButton cSharpButton = new JButton("C#");
        JButton dButton = new JButton("D");
        JButton dSharpButton = new JButton("D#");
        JButton eButton = new JButton("E");
        JButton fButton = new JButton("F");
        JButton fSharpButton = new JButton("F#");
        JButton gButton = new JButton("G");
        JButton gSharpButton = new JButton("G#");
        JButton aButton = new JButton("A");
        JButton aSharpButton = new JButton("A#");
        JButton bButton = new JButton("B");
        //shift Buttons
        JButton shiftLeftButton = new JButton("<");
        JButton shiftRightButton = new JButton(">");
        //save Button

        shiftRightButton.setPreferredSize(new Dimension(50, 150));
        cButton.setPreferredSize(new Dimension(50, 150));
        cSharpButton.setPreferredSize(new Dimension(50, 150));
        dButton.setPreferredSize(new Dimension(50, 150));
        dSharpButton.setPreferredSize(new Dimension(50, 150));
        eButton.setPreferredSize(new Dimension(50, 150));
        fButton.setPreferredSize(new Dimension(50, 150));
        fSharpButton.setPreferredSize(new Dimension(50, 150));
        gButton.setPreferredSize(new Dimension(50, 150));
        gSharpButton.setPreferredSize(new Dimension(50, 150));
        aButton.setPreferredSize(new Dimension(50, 150));
        aSharpButton.setPreferredSize(new Dimension(50, 150));
        bButton.setPreferredSize(new Dimension(50, 150));
        shiftLeftButton.setPreferredSize(new Dimension(50, 150));


        keyArea.add(shiftLeftButton);
        keyArea.add(cButton);
        keyArea.add(cSharpButton);
        keyArea.add(dButton);
        keyArea.add(dSharpButton);
        keyArea.add(eButton);
        keyArea.add(fButton);
        keyArea.add(fSharpButton);
        keyArea.add(gButton);
        keyArea.add(gSharpButton);
        keyArea.add(aButton);
        keyArea.add(aSharpButton);
        keyArea.add(bButton);
        keyArea.add(shiftRightButton);

        //Eventlisteners for Keys

        cButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record) {
                                pitchEvent(pitchList[0]);
                            }
                            else {
                                pitchEvent(pitchList[0]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[0]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        cSharpButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[1]);
                            else {
                                pitchEvent(pitchList[1]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[1]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        dButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[2]);
                            else {
                                pitchEvent(pitchList[2]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[2]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        dSharpButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[3]);
                            else {
                                pitchEvent(pitchList[3]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[3]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        eButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[4]);
                            else {
                                pitchEvent(pitchList[4]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[4]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        fButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[5]);
                            else {
                                pitchEvent(pitchList[5]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[5]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        fSharpButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[6]);
                            else {
                                pitchEvent(pitchList[6]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[6]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        gButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[7]);
                            else {
                                pitchEvent(pitchList[7]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[7]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        gSharpButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[8]);
                            else {
                                pitchEvent(pitchList[8]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[8]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        aButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[9]);
                            else {
                                pitchEvent(pitchList[9]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[9]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        aSharpButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[10]);
                            else {
                                pitchEvent(pitchList[10]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[10]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        bButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            if(!record)
                                pitchEvent(pitchList[11]);
                            else {
                                pitchEvent(pitchList[11]);
                                Globals.memory.setWord(Memory.dataBaseAddress + offset, pitchList[11]);
                                offset += 4;
                            }
                        } catch (AddressErrorException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

        shiftLeftButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        shiftOctave(LEFTSHIFT);
                    }
                }
        );

        shiftRightButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        shiftOctave(RIGHTSHIFT);
                    }
                }
        );

        return keyArea;
    }

    //Main Display
    protected JComponent buildMainDisplayArea() {

        JPanel mainFrame = new JPanel();

        mainFrame.setLayout(new BorderLayout());

        mainFrame.add(buildSelectionArea(), BorderLayout.PAGE_START);
        mainFrame.add(buildKeyArea(), BorderLayout.CENTER);

        return mainFrame;
    }

    //HELP

    protected JComponent getHelpComponent() {
        final String helpContent = "";
        JButton help = new JButton("Help");
        help.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        JOptionPane.showMessageDialog(theWindow, helpContent);
                    }
                });
        return help;
    }

    public VirtualPiano() {
        super(heading + ", " + version, heading);

    }

    public VirtualPiano(String title, String heading) {
        super(title, heading);
    }

    public static void main(String[] args) {
        new VirtualPiano(heading + ", " + version, heading);

    }

    @Override
    public String getName() {
        return "Virtual Piano";
    }

}





