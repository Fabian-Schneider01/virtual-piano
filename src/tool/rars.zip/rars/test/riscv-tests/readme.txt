The tests in this directory were generated and modified from the riscv-tests repository. They cover basic conformance of instructions to the specification.
